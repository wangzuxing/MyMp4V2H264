package com.example.mymp4v2h264;

import java.io.File;
import java.io.IOException;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class Mp4Activity extends Activity {
	static {
		System.loadLibrary("mp4v2");
		System.loadLibrary("mpm");
	}

	private Button converBtn; 
	private ProgressDialog pd;


	//public native void Mp4Encode(String h264, String mp4);
	public native boolean Mp4EncodeM(String h264, String aac, String mp4);
	
	/**
	 * ��ȡLAME�İ汾��Ϣ
	 * 
	 * @return
	 */
	//public native String[] getFaacVersion();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main2);

		pd = new ProgressDialog(this);
		
		converBtn = (Button) findViewById(R.id.conver_btn);
		converBtn.setOnClickListener(new OnClickListener() {
			@Override
		    public void onClick(View v){
				// Do something in response to button click
		    	convert(v);
		    }
		});
	}

	/**
	 * wavת��mp3
	 */
	public void convert(View view) {
		
		final String h264Path = Environment.getExternalStorageDirectory() + "/butterfly.h264";
		final String aacPath = Environment.getExternalStorageDirectory() + "/love.aac";
		final String mp4Path = Environment.getExternalStorageDirectory() + "/h264aac712.mp4";
		/*
		final String h264Path = Environment.getExternalStorageDirectory() + "/mediacodec0712tt.264";
		final String aacPath = Environment.getExternalStorageDirectory() + "/audioencoded712tt.aac";
		final String mp4Path = Environment.getExternalStorageDirectory() + "/h264aac712tt.mp4";
		*/
		File f = new File(Environment.getExternalStorageDirectory(), "h264aac712.mp4");
		try {
			 if(!f.exists()){
			    f.createNewFile();
			 }else{
				if(f.delete()){
				   Log.w("Mp4Activity", " mp4 file create again! ");
				   f.createNewFile();
				}
			}
		} catch (IOException e) {
			 e.printStackTrace();
		}
		
		//final String mp3Path = et_mp3.getText().toString().trim();
		//final String wavPath = et_wav.getText().toString().trim();
		File file = new File(h264Path);
		if(file.exists()){
		    Log.w("Mp4Activity", "      h264 file is exists!   ");
		}
		
		File file0 = new File(aacPath);
		if(file0.exists()){
		    Log.w("Mp4Activity", "     aac file is exists!   ");
		 }
		
		int size = (int) file.length();
		int size0 = (int) file0.length();
		
		System.out.println("h264Path =  " + size);
		System.out.println("aacPath  =  " + size0);
		if ("".equals(h264Path) || "".equals(mp4Path)) {
			Toast.makeText(Mp4Activity.this, "·������Ϊ��", 1).show();
			return;
		}
		/*
		pd.setMessage("H264 & AAC to MP4....");
		pd.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
		pd.setMax(size); // ���ý����������ֵ
		pd.setCancelable(false);
		pd.show();
		// ת���Ǹ���ʱ�Ĳ���������������Ҫ�������߳�ȥִ��
		*/
		new Thread() {

			@Override
			public void run() {
				//Mp4Encode(h264Path, mp4Path);
				Mp4EncodeM(h264Path, aacPath, mp4Path);
				//pd.dismiss();
			}

		}.start();
	}

	/**
	 * ���ý������Ľ��ȣ��ṩ��C���Ե���
	 * 
	 * @param progress
	 */
	public void setConvertProgress(int progress) {
		pd.setProgress(progress);
	}

}
