#include <stdio.h>
#include <jni.h>
#include <malloc.h>
#include <string.h>
#include "faac/faac.h"
#include <android/log.h>


#define LOG_TAG "System.out.c"
#define LOGD(...) ((void)__android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__))
#define LOGI(...) ((void)__android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__))
#define LOGW(...) ((void)__android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__))

typedef unsigned long   ULONG;
typedef unsigned int    UINT;
typedef unsigned char   BYTE;
typedef char            _TCHAR;

/*
wav是直接从cd中的音轨拷贝出来，和原cd音质一模一样，但是缺点是太大了，一张专辑有600兆
ape是采用无损压缩后的音乐，压缩率54％音质和wav一样，文件还原成wav后，文件md5值和原wav一样，一张专辑300兆，
这个编码是开源的，可以免费用
flac无损压缩，压缩率60％，生成文件比ape稍微大点，音质和wav一样，但是是不开源，付费使用的

wav是所有音乐的源头，flac和ape是它的压缩模式，用wav一半的容量还原wav一样的音质，所以ape和flac更受欢迎
*/

/**
 * 返回值 char* 这个代表char数组的首地址
 *  Jstring2CStr 把java中的jstring的类型转化成一个c语言中的char 字符串
 */
char* Jstring2CStr(JNIEnv* env, jstring jstr) {
	char* rtn = NULL;
	jclass clsstring = (*env)->FindClass(env, "java/lang/String"); //String
	jstring strencode = (*env)->NewStringUTF(env, "GB2312"); // 得到一个java字符串 "GB2312"
	jmethodID mid = (*env)->GetMethodID(env, clsstring, "getBytes",
			"(Ljava/lang/String;)[B"); //[ String.getBytes("gb2312");
	jbyteArray barr = (jbyteArray)(*env)->CallObjectMethod(env, jstr, mid,
			strencode); // String .getByte("GB2312");
	jsize alen = (*env)->GetArrayLength(env, barr); // byte数组的长度
	jbyte* ba = (*env)->GetByteArrayElements(env, barr, JNI_FALSE);
	if (alen > 0) {
		rtn = (char*) malloc(alen + 1); //"\0"
		memcpy(rtn, ba, alen);
		rtn[alen] = 0;
	}
	(*env)->ReleaseByteArrayElements(env, barr, ba, 0); //
	return rtn;
}

/**
 * 调用java代码 更新程序的进度条
 */
void publishJavaProgress(JNIEnv * env, jobject obj, jint progress) {
	// 1.找到java的MainActivity的class
	jclass clazz = (*env)->FindClass(env, "com/example/mymp4v2faac/FaacActivity");
	if (clazz == 0) {
		LOGI("can't find clazz");
	}
	//LOGI(" find clazz");

	//2 找到class 里面的方法定义
	jmethodID methodid = (*env)->GetMethodID(env, clazz, "setConvertProgress","(I)V");
	if (methodid == 0) {
		LOGI("can't find methodid");
	}
	//LOGI(" find methodid");

	//3 .调用方法
	(*env)->CallVoidMethod(env, obj, methodid, progress);
}

const char* cpcm;
const char* caac;

JNIEXPORT void JNICALL Java_com_example_mymp4v2faac_FaacActivity_faacEncode
(JNIEnv * env, jobject obj, jstring pcm, jstring aac)
{
	//char* cwav =Jstring2CStr(env,jwav) ;
	//char* cmp3=Jstring2CStr(env,jmp3);

	cpcm =Jstring2CStr(env,pcm) ;
	caac =Jstring2CStr(env,aac);

	/*
	const char* file0=(*env)->GetStringUTFChars(env,pcm,0);
	const char* file1=(*env)->GetStringUTFChars(env,aac,0);

	cpcm = file0;
	caac = file1;

	(*env)->ReleaseStringChars(env, pcm, file0);
    (*env)->ReleaseStringChars(env, aac, file1);
    */

    LOGW("faacEncode cpcm = %s", cpcm);
    LOGW("faacEncode caac = %s", caac);

    ULONG nSampleRate = 44100;  // 采样率
    UINT nChannels = 2;         // 声道数
    UINT nPCMBitSize = 16;      // 单样本位数
    ULONG nInputSamples = 0;
    ULONG nMaxOutputBytes = 0;

    int total=0;
    int nRet;
    faacEncHandle hEncoder;
    faacEncConfigurationPtr pConfiguration;

    int nBytesRead;
    long nPCMBufferSize;
    //BYTE* pbPCMBuffer;
    //BYTE* pbAACBuffer;

    FILE* fpIn; // PCM file for input
    FILE* fpOut; // AAC file for output

    //fpIn = fopen("/home/michael/Development/testspace/in.pcm", "rb");
    //fpOut = fopen("/home/michael/Development/testspace/out.aac", "wb");
    fpIn = fopen(cpcm, "rb");
    fpOut = fopen(caac, "wb");

    // (1) Open FAAC engine
    hEncoder = faacEncOpen(nSampleRate, nChannels, &nInputSamples, &nMaxOutputBytes);
    if(hEncoder == NULL)
    {
        printf("[ERROR] Failed to call faacEncOpen()\n");
        //return -1;
    }else{

    nPCMBufferSize = nInputSamples * nPCMBitSize / 8;
    //pbPCMBuffer = new BYTE [nPCMBufferSize];
    //pbAACBuffer = new BYTE [nMaxOutputBytes];
    BYTE pbPCMBuffer[nPCMBufferSize];
    BYTE pbAACBuffer[nMaxOutputBytes];

    LOGW("faacEncode nPCMBufferSize  = %ld", nPCMBufferSize);
    LOGW("faacEncode nMaxOutputBytes = %ld", nMaxOutputBytes);

    // (2.1) Get current encoding configuration
    pConfiguration = faacEncGetCurrentConfiguration(hEncoder);
    pConfiguration->inputFormat = FAAC_INPUT_16BIT;
    pConfiguration->aacObjectType = LOW;
    pConfiguration->allowMidside = 0;
    pConfiguration->outputFormat = 0; // Bitstream output format (0 = Raw; 1 = ADTS)
    pConfiguration->bitRate = 128000; // 12800

    // (2.2) Set encoding configuration
    nRet = faacEncSetConfiguration(hEncoder, pConfiguration);

    int i = 0, j=0;
    for(;;)
    {
        // 读入的实际字节数，最大不会超过nPCMBufferSize，一般只有读到文件尾时才不是这个值
        nBytesRead = fread(pbPCMBuffer, 1, nPCMBufferSize, fpIn);

        total +=  nBytesRead* sizeof(short int)*2;
        //LOGI("converting ....%d", total);
        j++;
        if(j>=50){
           j = 0;
           publishJavaProgress(env,obj,total);
        }

        // 输入样本数，用实际读入字节数计算，一般只有读到文件尾时才不是nPCMBufferSize/(nPCMBitSize/8);
        nInputSamples = nBytesRead / (nPCMBitSize / 8);

        // (3) Encode
        nRet = faacEncEncode(
        hEncoder, (int*) pbPCMBuffer, nInputSamples, pbAACBuffer, nMaxOutputBytes);

        fwrite(pbAACBuffer, 1, nRet, fpOut);

        i++;
        //printf("%d: faacEncEncode returns %d, total = %d\n", i, nRet, total);

        if(nBytesRead <= 0)
        {
            break;
        }
    }

    /*
    //need shield
    while(1)
    {
        // (3) Flushing
        nRet = faacEncEncode(
        hEncoder, (int*) pbPCMBuffer, 0, pbAACBuffer, nMaxOutputBytes);

        if(nRet <= 0)
        {
            break;
        }
    }
    */

    // (4) Close FAAC engine
    nRet = faacEncClose(hEncoder);

    //delete[] pbPCMBuffer;
    //delete[] pbAACBuffer;
    fclose(fpIn);
    fclose(fpOut);
    }
    //getchar();

    //return 0;
}

/*
//获取FAAC的版本信息

JNIEXPORT jstring JNICALL Java_com_example_mymp4v2faac_FaacActivity__getFaacVersion(
	JNIEnv * env, jobject obj) {
	char *faac_id;
	char *faac_copyright;
	jstring faac_info[2];

	//int FAACAPI faacEncGetVersion(char **faac_id_string,
	//			      char **faac_copyright_string);
	int ret = faacEncGetVersion(&faac_id, &faac_copyright);

	if(ret>=0){
	LOGI(" getFaacVersion success ");
	faac_info[0] = (*env)->NewStringUTF(env, faad_id);
	faac_info[1] = (*env)->NewStringUTF(env, faac_copyright);

	faac_info[0].concat(faac_info[1]);
	return faac_info[0];
	}else{
	LOGI(" getFaacVersion failed ");
	return "null";
	}
}
*/
