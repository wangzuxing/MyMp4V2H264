#include <cstdio>
#include "MP4Encoder.h"
#include <stdio.h>
#include <jni.h>
#include <malloc.h>
#include <android/log.h>
#include <string.h>

using namespace std;

#define LOG_TAG "libmpm"
#define LOGD(...) ((void)__android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__))
#define LOGI(...) ((void)__android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__))
#define LOGW(...) ((void)__android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__))


#define MP4ENCODER_ERROR(err) ((MP4EncoderResult)(-(err)))
#define DEFAULT_RECORD_TIME 0U

typedef enum
{
	MP4ENCODER_ENONE = 0,
	MP4ENCODER_E_CREATE_FAIL,
	MP4ENCODER_E_ADD_VIDEO_TRACK,
	MP4ENCODER_E_ADD_AUDIO_TRACK,
	MP4ENCODER_WARN_RECORD_OVER,
	MP4ENCODER_E_WRITE_VIDEO_DATA,
	MP4ENCODER_E_WRITE_AUDIO_DATA,
	MP4ENCODER_E_ALLOC_MEMORY_FAILED,
	MP4ENCODER_E_UNKONOWN
}MP4EncoderResult;


#define MIN_FRAME_SIZE 32
#define VIDEO_TIME_SCALE 90000
#define AUDIO_TIME_SCALE 44100
#define MOVIE_TIME_SCALE VIDEO_TIME_SCALE
#define PTS2TIME_SCALE(CurPTS, PrevPTS, timeScale) \
	((MP4Duration)((CurPTS - PrevPTS) * 1.0 / (double)(1e+6) * timeScale))

#define INVALID_PTS 0xFFFFFFFFFFFFFFFF
/* Warning: Followings are magic data originally */
#define DEFAULT_VIDEO_TRACK_NUM 3
#define DEFAULT_VIDEO_PROFILE_LEVEL 1
#define DEFAULT_AUDIO_PROFILE_LEVEL 2

MP4EncoderResult MP4CreateFile(const char *sFileName,unsigned uRecordTime = DEFAULT_RECORD_TIME);
MP4EncoderResult MP4AddH264Track(const uint8_t *sData, int nSize,int nWidth, int nHeight, int nFrameRate = 25);
MP4EncoderResult MP4AddAACTrack(const uint8_t *sData, int nSize);
MP4EncoderResult MP4WriteH264Data(uint8_t *sData, int nSize, uint64_t u64PTS);
MP4EncoderResult MP4WriteAACData(const uint8_t *sData, int nSize,uint64_t u64PTS);
void MP4ReleaseFile();

unsigned m_uSecond;
MP4FileHandle m_hFile;
bool m_bFirstAudio, m_bFirstVideo;
MP4TrackId m_videoTrack, m_audioTrack;
uint64_t m_u64AudioPTS, m_u64VideoPTS, m_u64FirstPTS, m_u64LastPTS;

void Release(MP4Encoder &encoder, FILE *&video, FILE *&audio);

#define MAX_BUFFER_SIZE 500000

uint8_t buf[MAX_BUFFER_SIZE];
bool success = false;
const char* mp4_s;

MP4EncoderResult MP4CreateFile(const char *sFileName,
	unsigned uRecordTime /* = DEFAULT_RECORD_TIME */)
{
	m_hFile = MP4Create(sFileName, 0);
	if (m_hFile == MP4_INVALID_FILE_HANDLE)
		return MP4ENCODER_ERROR(MP4ENCODER_E_CREATE_FAIL);

	if (!MP4SetTimeScale(m_hFile, MOVIE_TIME_SCALE))
		return MP4ENCODER_ERROR(MP4ENCODER_E_CREATE_FAIL);
	m_uSecond = uRecordTime;
	return MP4ENCODER_ENONE;
}

MP4EncoderResult MP4AddH264Track(const uint8_t *sData, int nSize,
	int nWidth, int nHeight, int nFrameRate/* = 25 */)
{
	int sps, pps;
	for (sps = 0; sps < nSize;)
		if (sData[sps++] == 0x00 && sData[sps++] == 0x00 && sData[sps++] == 0x00
			&& sData[sps++] == 0x01)
			break;
	for (pps = sps; pps < nSize;)
		if (sData[pps++] == 0x00 && sData[pps++] == 0x00 && sData[pps++] == 0x00
			&& sData[pps++] == 0x01)
			break;
	if (sps >= nSize || pps >= nSize)
		return MP4ENCODER_ERROR(MP4ENCODER_E_ADD_VIDEO_TRACK);

	m_videoTrack = MP4AddH264VideoTrack(m_hFile, VIDEO_TIME_SCALE,
		VIDEO_TIME_SCALE / nFrameRate, nWidth, nHeight,
		sData[sps + 1], sData[sps + 2], sData[sps + 3], DEFAULT_VIDEO_TRACK_NUM);
	if (MP4_INVALID_TRACK_ID == m_videoTrack)
		return MP4ENCODER_ERROR(MP4ENCODER_E_ADD_VIDEO_TRACK);

	MP4SetVideoProfileLevel(m_hFile, DEFAULT_VIDEO_PROFILE_LEVEL);
	MP4AddH264SequenceParameterSet(m_hFile, m_videoTrack, sData + sps,
		pps - sps - 4);
	MP4AddH264PictureParameterSet(m_hFile, m_videoTrack, sData + pps,
		nSize - pps);

	return MP4ENCODER_ENONE;
}

MP4EncoderResult MP4AddAACTrack(const uint8_t *sData, int nSize)
{
	m_audioTrack = MP4AddAudioTrack(m_hFile, AUDIO_TIME_SCALE,
		/**
		 * In fact, this is not a magic number. A formula might be:
		 * SampleRate * ChannelNum * 2 / SampleFormat
		 * 8000 * 1 * 2 / 16 (�ֽڶ��룬������ AV_SAMPLE_FMT_S16)
		 */
		2048, MP4_MPEG4_AUDIO_TYPE);
		//AUDIO_TIME_SCALE / 8, MP4_MPEG4_AUDIO_TYPE);
	if (MP4_INVALID_TRACK_ID == m_audioTrack)
		return MP4ENCODER_ERROR(MP4ENCODER_E_ADD_AUDIO_TRACK);

	MP4SetAudioProfileLevel(m_hFile, DEFAULT_AUDIO_PROFILE_LEVEL);

	if (!MP4SetTrackESConfiguration(m_hFile, m_audioTrack, sData, nSize))
		return MP4ENCODER_ERROR(MP4ENCODER_E_ADD_AUDIO_TRACK);

	return MP4ENCODER_ENONE;
}

MP4EncoderResult MP4WriteH264Data(uint8_t *sData, int nSize,
	uint64_t u64PTS)
{
	if (nSize < MIN_FRAME_SIZE)
		return MP4ENCODER_ENONE;
	bool result = false;
	sData[0] = (nSize - 4) >> 24;
	sData[1] = (nSize - 4) >> 16;
	sData[2] = (nSize - 4) >> 8;
	sData[3] = nSize - 4;
	if (m_bFirstVideo)
	{
		if (m_u64FirstPTS > u64PTS)
			m_u64FirstPTS = u64PTS;
		m_u64VideoPTS = u64PTS;
		m_bFirstVideo = false;
	}
	if ((sData[4] & 0x0F) == 5)
		result = MP4WriteSample(m_hFile, m_videoTrack, sData, nSize,
		PTS2TIME_SCALE(u64PTS, m_u64VideoPTS, VIDEO_TIME_SCALE));
	else
		result = MP4WriteSample(m_hFile, m_videoTrack, sData, nSize,
		PTS2TIME_SCALE(u64PTS, m_u64VideoPTS, VIDEO_TIME_SCALE), 0, false);
	if (!result)
		return MP4ENCODER_ERROR(MP4ENCODER_E_WRITE_VIDEO_DATA);
	m_u64LastPTS = m_u64VideoPTS = u64PTS;

	if (m_uSecond && (m_u64LastPTS - m_u64FirstPTS) / (1e+6) >= m_uSecond)
		return MP4ENCODER_ERROR(MP4ENCODER_WARN_RECORD_OVER);
	return MP4ENCODER_ENONE;
}

MP4EncoderResult MP4WriteAACData(const uint8_t *sData, int nSize,
	uint64_t u64PTS)
{
	if (nSize < MIN_FRAME_SIZE)
		return MP4ENCODER_ENONE;
	bool result = false;
	if (m_bFirstAudio)
	{
		if (m_u64FirstPTS > u64PTS)
			m_u64FirstPTS = u64PTS;
		m_u64AudioPTS = u64PTS;
		m_bFirstAudio = false;
	}
	result = MP4WriteSample(m_hFile, m_audioTrack, sData, nSize,
		PTS2TIME_SCALE(u64PTS, m_u64AudioPTS, AUDIO_TIME_SCALE));
	if (!result)
		return MP4ENCODER_ERROR(MP4ENCODER_E_WRITE_AUDIO_DATA);
	m_u64LastPTS = m_u64AudioPTS = u64PTS;
	if (m_uSecond && (m_u64LastPTS - m_u64FirstPTS) / (1e+6) >= m_uSecond)
		return MP4ENCODER_ERROR(MP4ENCODER_WARN_RECORD_OVER);
	return MP4ENCODER_ENONE;
}

void MP4ReleaseFile()
{
	if (m_hFile != MP4_INVALID_FILE_HANDLE)
	{
		MP4Close(m_hFile);
		m_hFile = MP4_INVALID_FILE_HANDLE;
	}
}

void Release(FILE *&video, FILE *&audio)
{
	if (video != NULL)
	{
		printf("Close video file.\n");
		fclose(video);
		video = NULL;
	}
	if (audio != NULL)
	{
		printf("Close audio file.\n");
		fclose(audio);
		audio = NULL;
	}
	MP4ReleaseFile();
	printf("Release buffer.\n");

	if (success)
		return;
	printf("Remove mp4 file.\n");
	remove(mp4_s);
}

uint64_t pts = 0;
int ret = -1, len = 0;
MP4EncoderResult AddH264Track(FILE *&fp)
{
	ret = fread(&len, sizeof(int), 1, fp);
	if (ret == 1)
	{
		ret = fread(&pts, sizeof(uint64_t), 1, fp);
		if (ret == 1)
		{
			ret = fread(buf, sizeof(uint8_t), len, fp);
			if (ret == len)
			{
			    uint8_t dta[25];
				for (int i = 0; i < 25; i++)
				{
					dta[i] = buf[i];
				}
				return MP4AddH264Track(buf, len, 240, 320);//640, 480);
			}
			else
				return MP4ENCODER_ERROR(MP4ENCODER_E_ADD_VIDEO_TRACK);
		}
		else
			return MP4ENCODER_ERROR(MP4ENCODER_E_ADD_VIDEO_TRACK);
	}
	else
		return MP4ENCODER_ERROR(MP4ENCODER_E_ADD_VIDEO_TRACK);
}

MP4EncoderResult AddAACTrack(FILE *&fp)
{
	ret = fread(&len, sizeof(int), 1, fp);
	if (ret == 1)
	{
		ret = fread(&pts, sizeof(uint64_t), 1, fp);
		if (ret == 1)
		{
			ret = fread(buf, sizeof(uint8_t), len, fp);
			if (ret == len)
				return MP4AddAACTrack(buf, len);
			else
				return MP4ENCODER_ERROR(MP4ENCODER_E_ADD_AUDIO_TRACK);
		}
		else
			return MP4ENCODER_ERROR(MP4ENCODER_E_ADD_AUDIO_TRACK);
	}
	else
		return MP4ENCODER_ERROR(MP4ENCODER_E_ADD_AUDIO_TRACK);
}

bool WriteH264Data(FILE *fp)
{
	bool endOfFile = false;
	MP4EncoderResult result;
	while (!endOfFile)
	{
		ret = fread(&len, sizeof(int), 1, fp);
		if (ret == 1)
		{
			ret = fread(&pts, sizeof(uint64_t), 1, fp);
			if (ret == 1)
			{
				ret = fread(buf, sizeof(uint8_t), len, fp);
				if (ret == len)

					result = MP4WriteH264Data(buf, len, pts);
				else
					result = MP4ENCODER_ERROR(MP4ENCODER_E_WRITE_VIDEO_DATA);
			}
			else
				result = MP4ENCODER_ERROR(MP4ENCODER_E_WRITE_VIDEO_DATA);
		}
		else
			endOfFile = true;
		if (result != MP4ENCODER_ENONE)
			return false;
	}
	return true;
}

bool WriteAACData(FILE *fp)
{
	bool endOfFile = false;
	MP4EncoderResult result;
	while (!endOfFile)
	{
		ret = fread(&len, sizeof(int), 1, fp);
		if (ret == 1)
		{
			ret = fread(&pts, sizeof(uint64_t), 1, fp);
			if (ret == 1)
			{
				ret = fread(buf, sizeof(uint8_t), len, fp);
				if (ret == len)
					result = MP4WriteAACData(buf, len, pts);
				else
					result = MP4ENCODER_ERROR(MP4ENCODER_E_WRITE_AUDIO_DATA);
			}
			else
				result = MP4ENCODER_ERROR(MP4ENCODER_E_WRITE_AUDIO_DATA);
		}
		else
			endOfFile = true;
		if (result != MP4ENCODER_ENONE)
			return false;
	}
	return true;
}

JNIEXPORT bool JNICALL Java_com_example_mymp4v2h264_Mp4Activity_Mp4EncodeM
 (JNIEnv *env, jclass clz, jstring video_ss, jstring audio_ss, jstring mp4_ss)
{
 	const char* video_s = env->GetStringUTFChars(video_ss, 0);
 	const char* audio_s = env->GetStringUTFChars(audio_ss, 0);

 	mp4_s = env->GetStringUTFChars(mp4_ss, 0);

 	LOGI("     START     ");
 	LOGI("     START     ");
 	if(video_s == NULL || audio_s == NULL)
 	{
 		return false;
 	}

 	FILE *video = fopen(video_s, "rb");
 	if (video == NULL){
 		printf("Could not open video file!\n");
 		return false;
 	}

	FILE *audio = fopen(audio_s, "rb");
 	if(audio == NULL){
 		printf("Could not open audio file!\n");
 		return false;
 	}


	bool ret = MP4CreateFile(mp4_s, 5);
	if(ret){
		Release(encoder, video, audio);
		return false;
	}
	LOGI("     MP4CreateFile     ");

	ret = AddH264Track(video);
	if(ret){
		Release(video, audio);
		return false;
	}
	LOGI("     AddH264Track     ");

    ret = AddAACTrack(audio);
    if(ret){
		Release(video, audio);
		return false;
	}
    LOGI("     AddAACTrack     ");

	WriteH264Data(video);
	WriteAACData(audio);

	success = true;
	Release(video, audio);

	LOGI("     END     ");
	LOGI("     END     ");

	env->ReleaseStringUTFChars(video_ss, 0);
	env->ReleaseStringUTFChars(audio_ss, 0);
	env->ReleaseStringUTFChars(mp4_ss, 0);

	return true;
}
