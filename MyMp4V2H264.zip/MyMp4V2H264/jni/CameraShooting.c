#include <string.h>  
#include "mp4v2/mp4v2.h"
#include <jni.h>
//#include "AppCameraShooting.h"  
  
MP4TrackId video;  
MP4TrackId audio;  
MP4FileHandle fileHandle;  
unsigned char sps_pps_640[17] = {0x67, 0x42, 0x40, 0x1F, 0x96 ,0x54, 0x05, 0x01, 0xED, 0x00, 0xF3, 0x9E, 0xA0, 0x68, 0xCE, 0x38, 0x80}; //存储sps和pps 
unsigned char sps_pps[17]; 
int video_width = 640;  
int video_height = 480;  
  
//视频录制的调用,实现初始化  
JNIEXPORT bool JNICALL Java_com_example_mymp4v2faac_TestMp4Activity_mp4init
(JNIEnv *env, jclass clz, jstring title, jint type)  
{  
    const char* local_title = (*env)->GetStringUTFChars(env,title, NULL);  
    //创建mp4文件  
    fileHandle = MP4Create(local_title, 0);  
    if(fileHandle == MP4_INVALID_FILE_HANDLE)  
    {  
        return false;  
    }  
    memcpy(sps_pps, sps_pps_640, 17);  
    video_width = 640;  
    video_height = 480;  
    //设置mp4文件的时间单位  
    MP4SetTimeScale(fileHandle, 90000);  
    //创建视频track //根据ISO/IEC 14496-10 可知sps的第二个，第三个，第四个字节分别是 AVCProfileIndication,profile_compat,AVCLevelIndication     其中90000/20  中的20>是fps  
    video = MP4AddH264VideoTrack(fileHandle, 90000, 90000/20, video_width, video_height, sps_pps[1], sps_pps[2], sps_pps[3], 3);  
    if(video == MP4_INVALID_TRACK_ID)  
    {  
        MP4Close(fileHandle, 0);  
        return false;  
    }  
    audio = MP4AddAudioTrack(fileHandle, 16000, 1024, MP4_MPEG2_AAC_LC_AUDIO_TYPE);  
    if(audio == MP4_INVALID_TRACK_ID)  
    {  
        MP4Close(fileHandle, 0);  
        return false;  
  
    }  
    //设置sps和pps  
    MP4AddH264SequenceParameterSet(fileHandle, video, sps_pps, 13);  
    MP4AddH264PictureParameterSet(fileHandle, video, sps_pps+13, 4);  
    MP4SetVideoProfileLevel(fileHandle, 0x7F);  
    MP4SetAudioProfileLevel(fileHandle, 0x02);  char *ubuffer;
    MP4SetTrackESConfiguration(fileHandle, audio, &ubuffer[0], 2);  
    (*env)->ReleaseStringUTFChars(env, title, local_title);  
    return true;  
} 

//添加视频帧的方法  
JNIEXPORT void JNICALL Java_com_example_mymp4v2faac_TestMp4Activity_mp4packVideo
(JNIEnv *env, jclass clz, jbyteArray data, jint size, jint keyframe)  
{  
    unsigned char *buf = (unsigned char *)(*env)->GetByteArrayElements(env, data, JNI_FALSE);  
    //if(video_type == 1){  
        int nalsize = size;  
        buf[0] = (nalsize & 0xff000000) >> 24;  
        buf[1] = (nalsize & 0x00ff0000) >> 16;  
        buf[2] = (nalsize & 0x0000ff00) >> 8;  
        buf[3] =  nalsize & 0x000000ff;  
        MP4WriteSample(fileHandle, video, buf, size, MP4_INVALID_DURATION, 0, keyframe);  
    //}  
    (*env)->ReleaseByteArrayElements(env, data, (jbyte *)buf, 0);  
}  
  
//添加音频帧的方法  
JNIEXPORT void JNICALL Java_com_example_mymp4v2faac_TestMp4Activity_mp4packAudio
(JNIEnv *env, jclass clz, jbyteArray data, jint size)  
{  
    uint8_t *bufaudio = (uint8_t *)(*env)->GetByteArrayElements(env, data, JNI_FALSE);  
    MP4WriteSample(fileHandle, audio, &bufaudio[7], size-7, MP4_INVALID_DURATION, 0, 1); //减去7为了删除adts头部的7个字节  
    (*env)->ReleaseByteArrayElements(env, data, (jbyte *)bufaudio, 0);  
}  
  
//视频录制结束调用  
JNIEXPORT void JNICALL Java_com_example_mymp4v2faac_TestMp4Activity_mp4close
(JNIEnv *env, jclass clz)  
{  
    MP4Close(fileHandle, 0);  
}
