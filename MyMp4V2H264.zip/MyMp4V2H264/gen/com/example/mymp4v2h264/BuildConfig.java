/** Automatically generated file. DO NOT MODIFY */
package com.example.mymp4v2h264;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}